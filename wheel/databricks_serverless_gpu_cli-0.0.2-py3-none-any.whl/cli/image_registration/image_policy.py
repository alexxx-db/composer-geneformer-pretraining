"""Image policy handling for SGCLI run command.

This module implements the image policy logic that determines how Docker images
are resolved and registered before launching a workload:

- `auto` (default): Use cached image if available, otherwise register
- `latest`: Always check source registry (requires resolve-sha endpoint)
"""

import logging
from enum import Enum
from typing import Optional

from cli.image_registration.image_client import (
    ImageClient,
    ImageRegistration,
    ImageStatus,
)

log = logging.getLogger(__name__)


class ImagePolicy(Enum):
    """Image resolution policy for docker images."""

    AUTO = "auto"
    LATEST = "latest"


class ImagePolicyHandler:
    """Handles image resolution based on the selected policy."""

    def __init__(
        self,
        workspace_host: Optional[str] = None,
        credentials_scope: Optional[str] = None,
        credentials_key: Optional[str] = None,
    ):
        """Initialize the handler.

        Args:
            workspace_host: Optional workspace host URL
            credentials_scope: Databricks secret scope for registry credentials
            credentials_key: Databricks secret key for registry credentials
        """
        self.client = ImageClient(workspace_host=workspace_host)
        self.credentials_scope = credentials_scope
        self.credentials_key = credentials_key

    def resolve_image(
        self,
        docker_image_url: str,
        policy: ImagePolicy = ImagePolicy.AUTO,
        wait_for_ready: bool = True,
        timeout_seconds: int = 900,
        verbose: bool = False,
    ) -> bool:
        """Resolve a docker image according to the specified policy.

        Args:
            docker_image_url: Docker image URL from YAML config
            policy: Image resolution policy (auto or latest)
            wait_for_ready: Whether to wait for image to become AVAILABLE
            timeout_seconds: Timeout for waiting
            verbose: If True, log progress every 15s (for CI/scripts).
                     If False, use TTY single-line overwrite (default).

        Returns:
            bool with if image is newly registered

        Raises:
            RuntimeError: If image registration or resolution fails
            TimeoutError: If waiting for image times out
        """
        log.info(f"Resolving image: {docker_image_url} (policy={policy.value})")

        # Check for existing registration
        existing = self.client.get_image(docker_image_url)

        if existing is not None:
            return self._handle_existing(
                docker_image_url=docker_image_url,
                existing=existing,
                policy=policy,
                wait_for_ready=wait_for_ready,
                timeout_seconds=timeout_seconds,
                verbose=verbose,
            )
        else:
            return self._handle_new(
                docker_image_url=docker_image_url,
                wait_for_ready=wait_for_ready,
                timeout_seconds=timeout_seconds,
                verbose=verbose,
            )

    def _handle_existing(
        self,
        docker_image_url: str,
        existing: ImageRegistration,
        policy: ImagePolicy,
        wait_for_ready: bool,
        timeout_seconds: int,
        verbose: bool,
    ) -> bool:
        """Handle case where user has an existing registration.

        For AUTO policy, uses cached image if AVAILABLE.
        For LATEST policy, would re-resolve SHA from source registry (not yet implemented).

        Returns:
            False (existing registration is never "newly registered")
        """
        log.info(f"Found existing registration: status={existing.status.value}")

        # For AUTO policy, use cached image if AVAILABLE
        # TODO [CNXT-1748] build out LATEST policy
        if existing.status == ImageStatus.AVAILABLE:
            return False  # Not newly registered

        # Image exists but not ready - wait for it
        if wait_for_ready:
            log.info("Image not ready, waiting for upload to complete...")
            self.client.wait_for_image_ready(
                docker_image_url=docker_image_url,
                timeout_seconds=timeout_seconds,
                verbose=verbose,
            )

        return False  # Not newly registered

    def _handle_new(
        self,
        docker_image_url: str,
        wait_for_ready: bool,
        timeout_seconds: int,
        verbose: bool,
    ) -> bool:
        """Handle case where user has no existing registration.

        Creates a new image registration and optionally waits for it to become AVAILABLE.

        Returns:
            True (new registration is always "newly registered")
        """
        log.info("No existing registration found, creating new registration...")

        registration = self.client.create_image(
            docker_image_url=docker_image_url,
            credentials_scope=self.credentials_scope,
            credentials_key=self.credentials_key,
        )

        log.info(f"Created registration: status={registration.status.value}")

        if wait_for_ready and registration.status != ImageStatus.AVAILABLE:
            log.info("Waiting for image to become available...")
            self.client.wait_for_image_ready(
                docker_image_url=docker_image_url,
                timeout_seconds=timeout_seconds,
                verbose=verbose,
            )
            log.info("Image ready")

        return True  # Newly registered


def parse_image_policy(policy_str: str) -> ImagePolicy:
    """Parse an image policy string to ImagePolicy enum.

    Args:
        policy_str: Policy string ("auto" or "latest")

    Returns:
        ImagePolicy enum value

    Raises:
        ValueError: If policy string is invalid
    """
    policy_str = policy_str.lower().strip()

    try:
        return ImagePolicy(policy_str)
    except ValueError:
        valid = ", ".join(p.value for p in ImagePolicy)
        raise ValueError(f"Invalid image policy: '{policy_str}'. Valid options: {valid}")
