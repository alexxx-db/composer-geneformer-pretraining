"""Image registration package for SGCLI.

This package provides functionality for registering and managing Docker images
for use with Serverless GPU Compute. It supports:

- Image registration with the AI Compute Manager Image Service
- Image policy handling (auto vs latest) for the `sgcli run` command
- URL normalization and SHA resolution
"""

from cli.image_registration.image_client import (
    ImageClient,
    ImageRegistration,
    ImageStatus,
    normalize_docker_image_url,
)
from cli.image_registration.image_policy import (
    ImagePolicy,
    ImagePolicyHandler,
    parse_image_policy,
)

__all__ = [
    "ImageClient",
    "ImageRegistration",
    "ImageStatus",
    "ImagePolicy",
    "ImagePolicyHandler",
    "normalize_docker_image_url",
    "parse_image_policy",
]
