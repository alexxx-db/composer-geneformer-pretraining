"""Docker image utilities for SGCLI."""

import logging
from typing import Any, Dict, Optional

from cli.image_registration import ImagePolicyHandler, parse_image_policy

log = logging.getLogger(__name__)


def _get_docker_image_url_from_yaml(raw_dict: Dict[str, Any]) -> Optional[str]:
    """Extract docker_image.url from the raw YAML dict if present.

    Args:
        raw_dict: Raw YAML configuration dictionary.

    Returns:
        Docker image URL string if present and valid, None otherwise.
    """
    environment = raw_dict.get("environment", {})
    if not isinstance(environment, dict):
        return None
    docker_image = environment.get("docker_image", {})
    if not isinstance(docker_image, dict):
        return None
    url = docker_image.get("url")
    if url and isinstance(url, str):
        return url.strip() or None
    return None


def resolve_docker_image(
    raw_dict: Dict[str, Any],
    image_policy_str: str,
    image_timeout: int,
    workspace_host: Optional[str],
    verbose: bool,
) -> bool:
    """Resolve docker image from YAML config if specified.

    Args:
        raw_dict: Raw YAML configuration dictionary.
        image_policy_str: Image policy string ("auto" or "latest").
        image_timeout: Timeout in seconds to wait for image to become available.
        workspace_host: Optional workspace host URL.
        verbose: If True, log progress every 15s. If False, use TTY overwrite.

    Returns:
        True if image was resolved, False if no docker image in config.
    """
    docker_image_url = _get_docker_image_url_from_yaml(raw_dict)
    if not docker_image_url:
        return False

    docker_image = raw_dict.get("environment", {}).get("docker_image", {})

    image_policy = parse_image_policy(image_policy_str)
    log.info(f"Docker image: {docker_image_url}")
    log.info(f"Image policy: {image_policy.value}")

    handler = ImagePolicyHandler(
        workspace_host=workspace_host,
        credentials_scope=docker_image.get("credentials_scope"),
        credentials_key=docker_image.get("credentials_key"),
    )

    newly_registered = handler.resolve_image(
        docker_image_url=docker_image_url,
        policy=image_policy,
        wait_for_ready=True,
        timeout_seconds=image_timeout,
        verbose=verbose,
    )

    if newly_registered:
        log.info("New image registered and ready")
    else:
        log.info("Using cached image")

    return True
