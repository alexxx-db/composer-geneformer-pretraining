# CLI Changelog

## Developer Instructions

When you make a non-trivial change to CLI add your change to the changelog as part of your PR. 
Follow the format:

CLI version 

- [Jira (as applicable)] Description

Example: 

Version 0.0.1 

- [CTNX-1583] Fix xyz


## Release Manager Instructions
When you bump up the Version in __init__.py update the future version here so that developers put there changes in the correct area. 

----------------------------------------
# Start of CLI Changelog

- Add your changes ALWAYS ADD TO THE TOP

Version 0.0.2

[CNXT-1716] Remove unique suffix from job run names. Experiment corresponds exactly to Job Run name.

Version 0.0.1

[CNXT-1727] Add changelog command.
[CNXT-1706] Fix get runs hyperlinks and add get status hyperlinks.
[CNXT-1713] Add experiment_name validation and reduce log level.
[CNXT-1624] Validate fields and gpu num during workload submission.
[CNXT-1538] Add Streaming Logs capability. 
